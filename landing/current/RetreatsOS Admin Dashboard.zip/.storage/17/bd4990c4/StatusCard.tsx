import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LucideIcon } from 'lucide-react';

interface StatusCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  status: 'healthy' | 'warning' | 'critical';
  trend?: 'up' | 'down' | 'stable';
  trendValue?: string;
}

const statusColors = {
  healthy: 'border-l-teal-400 bg-teal-400/5',
  warning: 'border-l-amber-400 bg-amber-400/5',
  critical: 'border-l-red-400 bg-red-400/5'
};

const statusBadgeColors = {
  healthy: 'bg-teal-400/20 text-teal-400 border-teal-400/30',
  warning: 'bg-amber-400/20 text-amber-400 border-amber-400/30',
  critical: 'bg-red-400/20 text-red-400 border-red-400/30'
};

export function StatusCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  status, 
  trend, 
  trendValue 
}: StatusCardProps) {
  return (
    <Card className={`border-l-4 ${statusColors[status]} bg-zinc-900 border-zinc-800`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-zinc-300">{title}</CardTitle>
        <Icon className="h-4 w-4 text-zinc-400" />
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold text-white">{value}</div>
            {subtitle && (
              <p className="text-xs text-zinc-500 mt-1">{subtitle}</p>
            )}
          </div>
          <div className="flex flex-col items-end gap-2">
            <Badge className={statusBadgeColors[status]}>
              {status === 'healthy' ? 'OK' : status === 'warning' ? 'Warning' : 'Critical'}
            </Badge>
            {trend && trendValue && (
              <div className={`text-xs ${
                trend === 'up' ? 'text-teal-400' : 
                trend === 'down' ? 'text-red-400' : 
                'text-zinc-400'
              }`}>
                {trend === 'up' ? '↗' : trend === 'down' ? '↘' : '→'} {trendValue}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}