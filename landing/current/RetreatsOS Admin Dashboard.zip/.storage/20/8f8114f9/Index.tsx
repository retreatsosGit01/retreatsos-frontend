import { AdminLayout } from '@/components/AdminLayout';
import { StatusCard } from '@/components/StatusCard';
import { MetricsChart } from '@/components/MetricsChart';
import { ActivityFeed } from '@/components/ActivityFeed';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Activity, 
  Users, 
  Calendar, 
  DollarSign, 
  Bot, 
  Database, 
  Server,
  Zap,
  Mail,
  Clock,
  HardDrive,
  Wifi,
  Shield,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Eye,
  Settings
} from 'lucide-react';

// Mock data for charts
const systemMetrics = [
  { time: '00:00', value: 95 },
  { time: '04:00', value: 98 },
  { time: '08:00', value: 92 },
  { time: '12:00', value: 96 },
  { time: '16:00', value: 94 },
  { time: '20:00', value: 99 },
];

const responseTimeData = [
  { time: '00:00', value: 120 },
  { time: '04:00', value: 85 },
  { time: '08:00', value: 150 },
  { time: '12:00', value: 95 },
  { time: '16:00', value: 110 },
  { time: '20:00', value: 75 },
];

export default function AdminDashboard() {
  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Hero Admin Header */}
        <section className="relative overflow-hidden rounded-xl bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 p-8">
          <div 
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: 'url(/assets/admin-dashboard-hero.jpg)',
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          />
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2">RetreatsOS Control Center</h1>
                <p className="text-zinc-300">The operational nerve center of your entire platform</p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="border-teal-400 text-teal-400 hover:bg-teal-400 hover:text-black">
                  <Eye className="h-4 w-4 mr-2" />
                  System Logs
                </Button>
                <Button className="bg-teal-400 text-black hover:bg-teal-300">
                  <Settings className="h-4 w-4 mr-2" />
                  Manage System
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-teal-400">99.99%</div>
                <div className="text-sm text-zinc-400">Uptime</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">1,247</div>
                <div className="text-sm text-zinc-400">Active Creators</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">3,891</div>
                <div className="text-sm text-zinc-400">Active Retreats</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">$847K</div>
                <div className="text-sm text-zinc-400">30d Revenue</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-teal-400">24/24</div>
                <div className="text-sm text-zinc-400">AI Agents</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">2m ago</div>
                <div className="text-sm text-zinc-400">Last Backup</div>
              </div>
            </div>
          </div>
        </section>

        {/* System Health Overview */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6">System Health Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatusCard
              title="API Response Time"
              value="89ms"
              subtitle="Average last 24h"
              icon={Zap}
              status="healthy"
              trend="down"
              trendValue="12ms"
            />
            <StatusCard
              title="Error Rate"
              value="0.02%"
              subtitle="Last 24 hours"
              icon={AlertTriangle}
              status="healthy"
              trend="down"
              trendValue="0.01%"
            />
            <StatusCard
              title="Email Deliverability"
              value="99.8%"
              subtitle="Success rate"
              icon={Mail}
              status="healthy"
              trend="up"
              trendValue="0.2%"
            />
            <StatusCard
              title="Database Health"
              value="Optimal"
              subtitle="All queries < 50ms"
              icon={Database}
              status="healthy"
            />
            <StatusCard
              title="Storage Usage"
              value="847GB"
              subtitle="68% of 1.2TB"
              icon={HardDrive}
              status="warning"
              trend="up"
              trendValue="12GB"
            />
            <StatusCard
              title="Active Connections"
              value="2,847"
              subtitle="Concurrent users"
              icon={Wifi}
              status="healthy"
              trend="up"
              trendValue="247"
            />
            <StatusCard
              title="AI Agents Queue"
              value="12"
              subtitle="Pending tasks"
              icon={Bot}
              status="healthy"
            />
            <StatusCard
              title="Backup Status"
              value="Synced"
              subtitle="Shadow sync OK"
              icon={Shield}
              status="healthy"
            />
          </div>
        </section>

        {/* Performance Charts */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6">Performance Metrics</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white">System Uptime (24h)</CardTitle>
              </CardHeader>
              <CardContent>
                <MetricsChart data={systemMetrics} color="#00D4AA" />
              </CardContent>
            </Card>
            
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white">API Response Time (24h)</CardTitle>
              </CardHeader>
              <CardContent>
                <MetricsChart data={responseTimeData} color="#F59E0B" />
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Management Overview */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6">Management Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Users & Accounts
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-zinc-300">Total Users</span>
                  <span className="text-white font-semibold">1,247</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-300">Active Today</span>
                  <span className="text-teal-400 font-semibold">892</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-300">Premium Users</span>
                  <span className="text-green-400 font-semibold">347</span>
                </div>
                <Button className="w-full bg-zinc-800 hover:bg-zinc-700 text-white">
                  Manage Users
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Retreats Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-zinc-300">Total Retreats</span>
                  <span className="text-white font-semibold">3,891</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-300">This Month</span>
                  <span className="text-teal-400 font-semibold">247</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-300">Upcoming</span>
                  <span className="text-amber-400 font-semibold">156</span>
                </div>
                <Button className="w-full bg-zinc-800 hover:bg-zinc-700 text-white">
                  View All Retreats
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Financial Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-zinc-300">Monthly Revenue</span>
                  <span className="text-green-400 font-semibold">$847K</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-300">Transactions</span>
                  <span className="text-white font-semibold">2,847</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-zinc-300">Failed Payments</span>
                  <span className="text-red-400 font-semibold">12</span>
                </div>
                <Button className="w-full bg-zinc-800 hover:bg-zinc-700 text-white">
                  Financial Reports
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Activity Feed */}
        <section>
          <h2 className="text-2xl font-bold text-white mb-6">Recent Activity</h2>
          <ActivityFeed />
        </section>
      </div>
    </AdminLayout>
  );
}