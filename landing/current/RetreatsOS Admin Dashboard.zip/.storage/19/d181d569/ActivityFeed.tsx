import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Calendar, 
  DollarSign, 
  Bot, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Filter
} from 'lucide-react';

interface ActivityItem {
  id: string;
  type: 'retreat' | 'payment' | 'ai' | 'error' | 'system';
  title: string;
  description: string;
  timestamp: string;
  status: 'success' | 'warning' | 'error';
  user?: string;
}

const mockActivities: ActivityItem[] = [
  {
    id: '1',
    type: 'retreat',
    title: 'New Retreat Created',
    description: 'Mindfulness Retreat in Bali by Sarah Johnson',
    timestamp: '2 minutes ago',
    status: 'success',
    user: 'Sarah Johnson'
  },
  {
    id: '2',
    type: 'payment',
    title: 'Payment Processed',
    description: '$2,450 payment completed for Yoga Retreat',
    timestamp: '5 minutes ago',
    status: 'success',
    user: 'Mike Chen'
  },
  {
    id: '3',
    type: 'ai',
    title: 'AI Agent Posted',
    description: 'Instagram post published for Mountain Retreat',
    timestamp: '12 minutes ago',
    status: 'success'
  },
  {
    id: '4',
    type: 'error',
    title: 'Email Delivery Failed',
    description: 'Welcome email bounce for user@example.com',
    timestamp: '18 minutes ago',
    status: 'error',
    user: 'System'
  },
  {
    id: '5',
    type: 'system',
    title: 'Backup Completed',
    description: 'Daily backup completed successfully (2.3GB)',
    timestamp: '1 hour ago',
    status: 'success'
  }
];

const typeIcons = {
  retreat: Calendar,
  payment: DollarSign,
  ai: Bot,
  error: AlertTriangle,
  system: CheckCircle
};

const statusColors = {
  success: 'bg-teal-400/20 text-teal-400',
  warning: 'bg-amber-400/20 text-amber-400',
  error: 'bg-red-400/20 text-red-400'
};

export function ActivityFeed() {
  return (
    <Card className="bg-zinc-900 border-zinc-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">Global Activity Feed</CardTitle>
          <div className="flex items-center gap-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-32 bg-zinc-800 border-zinc-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700">
                <SelectItem value="all">All Events</SelectItem>
                <SelectItem value="retreat">Retreats</SelectItem>
                <SelectItem value="payment">Payments</SelectItem>
                <SelectItem value="ai">AI Activity</SelectItem>
                <SelectItem value="error">Errors Only</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" className="border-zinc-700 text-zinc-300 hover:text-white">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {mockActivities.map((activity) => {
          const IconComponent = typeIcons[activity.type];
          return (
            <div key={activity.id} className="flex items-start gap-4 p-4 rounded-lg bg-zinc-800/50 hover:bg-zinc-800 transition-colors">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-full bg-zinc-700 flex items-center justify-center">
                  <IconComponent className="h-5 w-5 text-zinc-300" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-medium text-white">{activity.title}</h4>
                  <Badge className={statusColors[activity.status]}>
                    {activity.status}
                  </Badge>
                </div>
                <p className="text-sm text-zinc-400 mt-1">{activity.description}</p>
                <div className="flex items-center gap-4 mt-2 text-xs text-zinc-500">
                  <span>{activity.timestamp}</span>
                  {activity.user && <span>by {activity.user}</span>}
                </div>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}