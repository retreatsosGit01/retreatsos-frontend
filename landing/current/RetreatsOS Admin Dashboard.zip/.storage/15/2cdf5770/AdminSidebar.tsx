import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupContent, 
  SidebarGroupLabel, 
  SidebarMenu, 
  SidebarMenuButton, 
  SidebarMenuItem 
} from '@/components/ui/sidebar';
import { 
  LayoutDashboard, 
  Activity, 
  Users, 
  Calendar, 
  DollarSign, 
  Bot, 
  Database, 
  Settings,
  Shield,
  FileText
} from 'lucide-react';

const menuItems = [
  {
    title: "Overview",
    items: [
      { title: "Dashboard", icon: LayoutDashboard, url: "#dashboard" },
      { title: "System Health", icon: Activity, url: "#health" },
    ]
  },
  {
    title: "Management",
    items: [
      { title: "Users & Accounts", icon: Users, url: "#users" },
      { title: "Retreats", icon: Calendar, url: "#retreats" },
      { title: "Financial", icon: DollarSign, url: "#financial" },
    ]
  },
  {
    title: "Operations",
    items: [
      { title: "AI Agents", icon: Bot, url: "#agents" },
      { title: "Backup & Sync", icon: Database, url: "#backup" },
      { title: "Activity Feed", icon: FileText, url: "#activity" },
    ]
  },
  {
    title: "System",
    items: [
      { title: "Settings", icon: Settings, url: "#settings" },
    ]
  }
];

export function AdminSidebar() {
  return (
    <Sidebar className="border-r border-zinc-800">
      <SidebarContent className="bg-zinc-950">
        <div className="p-6">
          <div className="flex items-center gap-2">
            <Shield className="h-8 w-8 text-teal-400" />
            <div>
              <h2 className="text-lg font-bold text-white">RetreatsOS</h2>
              <p className="text-xs text-zinc-400">Admin Panel</p>
            </div>
          </div>
        </div>
        
        {menuItems.map((group) => (
          <SidebarGroup key={group.title}>
            <SidebarGroupLabel className="text-zinc-400 text-xs uppercase tracking-wider">
              {group.title}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {group.items.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <a href={item.url} className="flex items-center gap-3 text-zinc-300 hover:text-white hover:bg-zinc-800 rounded-lg transition-colors">
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
    </Sidebar>
  );
}