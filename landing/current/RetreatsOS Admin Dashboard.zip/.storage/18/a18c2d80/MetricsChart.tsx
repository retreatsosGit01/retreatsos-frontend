import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface MetricsChartProps {
  data: Array<{
    time: string;
    value: number;
  }>;
  color?: string;
  height?: number;
}

export function MetricsChart({ data, color = '#00D4AA', height = 200 }: MetricsChartProps) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="#27272A" />
        <XAxis 
          dataKey="time" 
          stroke="#71717A"
          fontSize={12}
        />
        <YAxis 
          stroke="#71717A"
          fontSize={12}
        />
        <Tooltip 
          contentStyle={{
            backgroundColor: '#18181B',
            border: '1px solid #27272A',
            borderRadius: '8px',
            color: '#FFFFFF'
          }}
        />
        <Line 
          type="monotone" 
          dataKey="value" 
          stroke={color} 
          strokeWidth={2}
          dot={{ fill: color, strokeWidth: 2, r: 4 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}