import { Bell, Search, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { SidebarTrigger } from '@/components/ui/sidebar';

export function AdminHeader() {
  return (
    <header className="border-b border-zinc-800 bg-zinc-950 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <SidebarTrigger className="text-zinc-400 hover:text-white" />
          <div>
            <h1 className="text-xl font-bold text-white">System Control Center</h1>
            <p className="text-sm text-zinc-400">Monitor everything. Control everything. Run everything.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-zinc-400" />
            <Input 
              placeholder="Search system..." 
              className="pl-10 w-64 bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500"
            />
          </div>
          
          <Button variant="ghost" size="icon" className="relative text-zinc-400 hover:text-white">
            <Bell className="h-5 w-5" />
            <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-xs flex items-center justify-center p-0">
              3
            </Badge>
          </Button>
          
          <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-white">
            <User className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
}